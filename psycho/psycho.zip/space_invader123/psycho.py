import pygame
from pygame import mixer  # for music
import random
import math
from PIL import Image

# Initialize the game
pygame.init()

# Create the screen
screen = pygame.display.set_mode((900,800))

# Background
background = pygame.image.load('images/home.jpg')

# Sound
mixer.music.load('sounds/background.mp3')
mixer.music.play(loops=-1)

# Caption and Icon
pygame.display.set_caption("psycho")
icon = pygame.image.load("images/bikini_pink_32x32.jpg")
pygame.display.set_icon(icon)

# Score
score_value = 0
font = pygame.font.Font('fonts/Mohawk.ttf', 32)

textX = 10
textY = 10

def show_score(x, y):
    score = font.render("Score : " + str(score_value), True, (255,0,0))
    screen.blit(score, (x,y))


# Player
playerImg = pygame.image.load("images/玉足.jpg")
playerX = 370
playerY = 650
playerX_change = 0
def player(x, y):
    screen.blit(playerImg, (x, y))


# Enemy
enemyImg = []
enemyX = []
enemyY = []
enemyX_change = []
enemyY_change = []
num_of_enemies = 5

# enemyImgOrig = Image.open('images/fulafuegao.png')
# print("enemy size_before:" + str(enemyImgOrig.size))
# enemyImgOrig = enemyImgOrig.resize((100,100))
# print("enemy size_after:" + str(enemyImgOrig.size))
# enemyImgOrig.save('images/fulafuegao_100x100.png')

# iconImage=Image.open('images/bikini_pink.jpg')
# print("icon_before:" + str(iconImage.size))
# iconImage = iconImage.resize((32,32))
# print("icon_after:" + str(iconImage.size))
# iconImage.save('images/bikini_pink_32x32.jpg')

for i in range(num_of_enemies):
    enemyimg_load = pygame.image.load('images/fulafuegao_100x100.png')
    enemyImg.append(enemyimg_load)
    enemyX.append(random.randint(0,736))
    enemyY.append(random.randint(50, 150))
    enemyX_change.append(1)
    enemyY_change.append(40)
def enemy(x,y,i):
    screen.blit(enemyImg[i], (x,y))


# Bullet
## ready - you can't see the bullet on the screen
## fire - the bullet is currently moving
bulletImg = pygame.image.load("images/气体.webp")
bulletX = 0
bulletY = 690
bulletX_change = 0
bulletY_change = 5
bullet_state = "ready"  ## only 2 states: ready / fire.
def fire_bullet(x, y):
    global bullet_state
    bullet_state = "fire"
    screen.blit(bulletImg, (x+16, y+10))

def isCollision(enemyX, enemyY, bulletX, bulletY):
    distance = math.sqrt(math.pow(enemyX - bulletX, 2) + (math.pow(enemyY - bulletY, 2)))
    if distance < 27:
        return True
    else:
        return False



# Game Loop
running = True
while running==True:
    # RGB = Red, Green, Blue
    screen.fill(color = (0,0,255))
    # Background image
    screen.blit(background, (0,0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        # if keystroke is pressed, check whether its right or left
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerX_change = -5
            if event.key == pygame.K_RIGHT:
                playerX_change = 5
            if event.key == pygame.K_SPACE:
                if bullet_state is "ready":
                    bulletSound = mixer.Sound("sounds/laser.wav")
                    bulletSound.play()
                    # Get the current x coordinate of the spaceship
                    bulletX = playerX
                    fire_bullet(bulletX, bulletY)
            if event.key == pygame.K_ESCAPE:
                running = False

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerX_change = 0
    

    # player movement
    playerX = playerX + playerX_change
    if playerX <= 0:
        playerX = 0
    elif playerX >= 530:
        playerX = 530

    
    # enemy movement
    for i in range(num_of_enemies):
        enemyX[i] += enemyX_change[i]
        if enemyX[i] <= 0:
            enemyX_change[i] = 1
            enemyY[i] += enemyY_change[i]
        elif enemyX[i] >= 736:
            enemyX_change[i] = -1
            enemyY[i] += enemyY_change[i]
        # enemyY[i] += enemyY_change[i]
        enemy(enemyX[i], enemyY[i], i)


        # Collision
        collision = isCollision(enemyX[i], enemyY[i], bulletX, bulletY)
        if collision:
            explosionSound = mixer.Sound("sounds/explosion.wav")
            explosionSound.play()
            bulletY = 480
            bullet_state = "ready"
            score_value += 1
            enemyX[i] = random.randint(0, 736)
            enemyY[i] = random.randint(50, 150)
    

    # Bullet Movement
    if bulletY <= 0:  #top of the screen
        bulletY = 690  #bottom of the screen
        bullet_state = "ready"
    if bullet_state is "fire":
        fire_bullet(bulletX, bulletY)
        bulletY -= bulletY_change


        

    player(playerX, playerY)
    show_score(textX,textY)

    pygame.display.update()
